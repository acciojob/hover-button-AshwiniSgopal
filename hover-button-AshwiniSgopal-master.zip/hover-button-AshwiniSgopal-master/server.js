const app = require("./index.js");
app.listen(3000, () => {
  console.log('server started');
});